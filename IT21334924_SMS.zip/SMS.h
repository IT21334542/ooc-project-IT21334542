#include <string>
class SMS
{
    private:
    string phone[10];
};
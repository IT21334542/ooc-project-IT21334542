#pragma once
class Report {
private:
	int quantity;
	float price;



public:
	Report();
	Report(int Qty, float Price);

};
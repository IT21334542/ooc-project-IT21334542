using namespace std;
#include"Report.h"


int main()
{
	Report report1;
	report();
	Report report2(32, 4500.00);
	report();
	return 0;
}
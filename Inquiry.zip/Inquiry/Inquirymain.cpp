#include <iostream>
using namespace std;
#include"Inquiry.h"


int main()
{
    Inquiry inq1;
    display inquiry();

    Inquiry inq2;
    display inquiry("regarding discount offers", "kumara@gmail.com", 0112504422);
    return 0;
}
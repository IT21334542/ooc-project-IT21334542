#include <iostream>
#include <string>

using namespace std;

class notification
{
    private:
    string notificationID;
    string date;
    string content;
    
    public:
    void sendNotification(string pnotificationID, string pdate, string pcontent);
    void display();
};

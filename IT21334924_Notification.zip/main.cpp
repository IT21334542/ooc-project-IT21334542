int main()
{
notification not1 ;
not1.sendNotification("001","2022.05.19","Hey You added 2 new items in shopping cart");
not1.display();
}

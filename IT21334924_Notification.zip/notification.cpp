void notification::sendNotification(string pnotificationID, string pdate, string pcontent){
	notificationID=pnotificationID;
	date=pdate;
  content=pcontent;
	};
void notification::display(){
  cout<<"NotificationID = "<<notificationID<<endl;
  cout<<"Date = "<<date<<endl;
  cout<<"content = "<<content<<endl;
}
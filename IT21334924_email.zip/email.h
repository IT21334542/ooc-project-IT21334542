#include <string>
class email 
{
    private:
    string email;
    
    public:
    	void setemail(string pemail);
    
};
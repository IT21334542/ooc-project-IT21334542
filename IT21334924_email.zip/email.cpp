void email::setemail(string pemail){
	pemail=email;
};